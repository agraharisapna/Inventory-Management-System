from django.shortcuts import render, redirect
from .models import *
from django.contrib import messages


# Create your views here.

def Add_Product(request):

    if request.method == "POST":

        name   = request.POST.get('name')
        description = request.POST.get('description')
        quantity = request.POST.get('quantity')
        price = request.POST.get('price')

        create_product = Products.objects.create(name=name, description=description,
            quantity=quantity, price=price)

        create_product.save()

        messages.success(request, "Product Added successfully !!")

        return redirect('/add-product/')

    return render(request, 'add_product.html')


def Dashboard_page(request):
    products = Products.objects.all()
    return render(request, 'dashboard.html', {'products': products})


def Delete_product(request, id):
    if request.method=="POST":
        product_del = Products.objects.get(pk=id)    
        product_del.delete()
        return redirect('dashboard')
    
    return render(request, 'dashboard.html')

    
def Update_product(request, id):
    products = Products.objects.get(pk=id)

    if request.method == "POST":

        name = request.POST.get('name')  
        description  = request.POST.get('description')
        quantity = request.POST.get('quantity')
        price = request.POST.get('price')

        products.name = name
        products.description = description 
        products.quantity = quantity
        products.price = price

        products.save()

        messages.success(request, "Product Saved successfully !!")
    
        return redirect('dashboard')
        

    return render(request, 'update.html', {'products': products})