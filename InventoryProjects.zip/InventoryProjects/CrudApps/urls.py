from django.urls import path
from . import views

urlpatterns = [
    path('add-product/', views.Add_Product, name="Add_Product"),
    path('delete_product/<int:id>/', views.Delete_product, name='delete_product'),
    path('<int:id>/', views.Update_product, name='update_product'),
    path('dashboard/', views.Dashboard_page, name='dashboard'),

]